# PNNS Android Client (Full-Featured)

Features:
- Pick image from **Gallery** (add camera easily if needed)
- Extract **embedding** (demo: simple image pooling to 128-dim; replace with TF Lite model for production)
- Send embedding to server, get **Top-K** matches (photo + similarity score)
- Display results in a **RecyclerView** with thumbnails fetched from server

## Quick Start (Plain Mode)

1. Start the server from `../server`:
   ```bash
   uvicorn server:app --host 0.0.0.0 --port 8000 --reload
   ```

2. Open this project in **Android Studio**.
3. Make sure the app points to the server URL (default for emulator: `http://10.0.2.2:8000`).  
   You can change it in `MainActivity.kt` (`serverBase` variable).
4. Run on emulator/device.
5. Tap **Pick from Gallery**, select an image, then tap **Search (Top-K)**.

## Switching to HE Mode (CKKS via JNI)
- This project includes **stubs** for JNI (`HEUtils.java`, `app/src/main/cpp/*`).
- To enable HE mode:
  1. Build Microsoft **SEAL** for Android ABIs you need.
  2. Link SEAL libs in `CMakeLists.txt` and implement JNI in `he_jni.cpp`.
  3. Expose methods in `HEUtils` (e.g., `getContext()`, `encryptEmbedding(...)`).
  4. On server:
     - `pip install tenseal`
     - `POST /set_context` with client context (no secret key).
     - `POST /pnns?mode=he&topk=...` with hex-serialized encrypted vector.
  5. Parse and decrypt scores on client.

## Using a TF Lite Model for Embeddings
- Put your `.tflite` model into `app/src/main/assets/` (e.g., FaceNet/MobileNet).
- Replace `extractEmbedding(...)` in `MainActivity.kt` to run the model and produce a 128-dim vector.

## Notes
- Plain mode is for **end-to-end UX testing**. It is **not private**.
- HE mode requires extra setup but preserves privacy.
