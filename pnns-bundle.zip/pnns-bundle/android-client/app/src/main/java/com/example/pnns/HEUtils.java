package com.example.pnns;

// Placeholder JNI wrapper. For now unused (mode=plain).
// When you integrate Microsoft SEAL via NDK, expose methods like:
//
// public native String getContext();
// public native String encryptEmbedding(float[] embedding);
// public native float[] decryptScores(String[] encScoresHex);
//
// Then switch MainActivity mode to "he".
public class HEUtils {
    static {
        // System.loadLibrary("he_jni"); // Uncomment when you add the native lib
    }
}
