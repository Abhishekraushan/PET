package com.example.pnns

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class ResultsAdapter : RecyclerView.Adapter<ResultsAdapter.VH>() {

    private val data = mutableListOf<ResultRow>()

    fun submit(newData: List<ResultRow>) {
        data.clear()
        data.addAll(newData)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_result, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = data[position]
        holder.title.text = "Photo ID: ${row.id}"
        holder.score.text = "Score: %.4f".format(row.score)
        holder.thumb.load(row.imgUrl)
    }

    override fun getItemCount(): Int = data.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.imgThumb)
        val title: TextView = v.findViewById(R.id.txtTitle)
        val score: TextView = v.findViewById(R.id.txtScore)
    }
}
