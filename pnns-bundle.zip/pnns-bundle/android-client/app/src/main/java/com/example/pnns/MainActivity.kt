package com.example.pnns

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var previewImage: ImageView
    private lateinit var resultsList: RecyclerView
    private val adapter = ResultsAdapter()
    private var selectedBitmap: Bitmap? = null

    private val client = OkHttpClient()
    private val gson = Gson()

    // Adjust to your server IP if needed
    private val serverBase = "http://10.0.2.2:8000" // Android emulator -> host

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewImage = findViewById(R.id.previewImage)
        resultsList = findViewById(R.id.resultsList)
        resultsList.layoutManager = LinearLayoutManager(this)
        resultsList.adapter = adapter

        val btnPick: Button = findViewById(R.id.btnPick)
        val btnSearch: Button = findViewById(R.id.btnSearch)

        btnPick.setOnClickListener { pickImageFromGallery() }
        btnSearch.setOnClickListener { doSearchTopK() }
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val uri: Uri? = data?.data
            if (uri != null) {
                val bmp = decodeBitmap(uri)
                if (bmp != null) {
                    selectedBitmap = bmp
                    previewImage.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun decodeBitmap(uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                val src = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(src)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun extractEmbedding(bitmap: Bitmap): FloatArray {
        // --- Simplified embedding (for demo): downscale, normalize pixels, flatten to 128 dims ---
        // If you add a TFLite model, replace this method to run the model and return its embedding.
        val scaled = Bitmap.createScaledBitmap(bitmap, 32, 32, true)
        val floats = FloatArray(32 * 32 * 3)
        var idx = 0
        for (y in 0 until 32) {
            for (x in 0 until 32) {
                val c = scaled.getPixel(x, y)
                val r = ((c shr 16) and 0xFF) / 255.0f
                val g = ((c shr 8) and 0xFF) / 255.0f
                val b = (c and 0xFF) / 255.0f
                floats[idx++] = r
                floats[idx++] = g
                floats[idx++] = b
            }
        }
        // Pool down to 128 dims by simple chunked averaging
        val out = FloatArray(128)
        val chunk = floats.size / 128
        for (i in 0 until 128) {
            var s = 0.0
            for (j in 0 until chunk) s += floats[i * chunk + j]
            out[i] = (s / chunk).toFloat()
        }
        return out
    }

    private fun doSearchTopK() {
        val bmp = selectedBitmap
        if (bmp == null) {
            Toast.makeText(this, "Pick a photo first", Toast.LENGTH_SHORT).show()
            return
        }

        val emb = extractEmbedding(bmp)

        thread {
            try {
                val mode = "plain" // change to "he" when JNI/SEAL is integrated
                val topk = 5
                val payload = mapOf("query" to emb.toList())
                val json = gson.toJson(payload)
                val req = Request.Builder()
                    .url("$serverBase/pnns?mode=$mode&topk=$topk")
                    .post(json.toRequestBody("application/json".toMediaType()))
                    .build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string() ?: "{}"
                val result = gson.fromJson(body, PNNSResponse::class.java)

                val rows = mutableListOf<ResultRow>()
                result.results?.forEach {
                    rows.add(ResultRow(it.id ?: 0, it.score ?: 0.0, "$serverBase/get_photo/${it.id}"))
                }

                runOnUiThread {
                    adapter.submit(rows)
                }

            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
