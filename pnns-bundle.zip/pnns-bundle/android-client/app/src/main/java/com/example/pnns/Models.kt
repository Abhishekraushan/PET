package com.example.pnns

data class PNNSResponse(
    val mode: String? = null,
    val results: List<ResultItem>? = null
)

data class ResultItem(
    val id: Int? = null,
    val score: Double? = null
)

data class ResultRow(
    val id: Int,
    val score: Double,
    val imgUrl: String
)
