#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_pnns_HEUtils_dummy(JNIEnv* env, jobject thiz) {
    std::string s = "JNI ready";
    return env->NewStringUTF(s.c_str());
}

// TODO: Implement real JNI bindings to Microsoft SEAL for CKKS.
