# PNNS Client–Server Demo Bundle

This zip contains:
- `server/` — FastAPI backend (PNNS, plain & optional HE)
- `android-client/` — Full-featured Android app (gallery picker, Top-K results)

## Run Server

```bash
cd server
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000 --reload
```

## Build Android App
- Open `android-client/` in Android Studio.
- Run on emulator/device.
- The default server base URL is `http://10.0.2.2:8000` (works for emulator).

## HE Mode (Optional)
- Install `tenseal` on the server and implement JNI for Microsoft SEAL on Android.
- Use `/set_context` then `/pnns?mode=he` as described in the server README.

## Disclaimer
- The demo embeddings are synthetic. Replace with real embeddings for meaningful similarity.
- Plain mode is not private; use HE mode for privacy-preserving PNNS.
