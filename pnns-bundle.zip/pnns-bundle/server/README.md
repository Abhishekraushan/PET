# PNNS Demo Server

FastAPI backend for Private Nearest Neighbor Search (PNNS). Supports:
- **Plain mode** (no encryption) for easy end-to-end testing.
- **HE mode** with **TenSEAL CKKS** for encrypted vector similarity (optional).

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

> To enable HE mode, also install TenSEAL (requires PyTorch runtime):  
> `pip install tenseal`

## Run

```bash
uvicorn server:app --host 0.0.0.0 --port 8000 --reload
```

## API

- `GET /health` → server status
- `POST /pnns?mode=plain&topk=3`
  - Body: `{"query":[float,...]}`
  - Returns: Top-K results with cosine similarity.
- `POST /set_context` (HE mode only)
  - Body: `{"context":"<serialized context str>"}`
- `POST /pnns?mode=he&topk=3`
  - Body: `{"query":"<hex-serialized ckks_vector>"}`
  - Returns: List of `{id, score}` where `score` is hex of encrypted dot product.
- `GET /get_photo/{id}` → JPEG image

## Notes
- Demo uses **random embeddings** for the sample images. Replace with real embeddings for meaningful results.
- For production, precompute embeddings per photo and persist them.
