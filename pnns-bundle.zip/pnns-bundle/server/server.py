from fastapi import FastAPI, Request, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import numpy as np
import os
from typing import List, Dict, Any

# Optional HE imports; server can run in plaintext mode without TenSEAL
try:
    import tenseal as ts
    TENSEAL_AVAILABLE = True
except Exception:
    TENSEAL_AVAILABLE = False

app = FastAPI(title="PNNS Demo Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

PHOTOS = {
    1: {"file": "photos/img1.jpg"},
    2: {"file": "photos/img2.jpg"},
    3: {"file": "photos/img3.jpg"},
    4: {"file": "photos/img4.jpg"},
    5: {"file": "photos/img5.jpg"},
    6: {"file": "photos/img6.jpg"},
}

# For demo, we create random embeddings and keep them stable on server start.
# In a real system, you'd compute embeddings for the photos once and persist them.
np.random.seed(42)
EMBEDDINGS = {pid: np.random.rand(128).astype(np.float64) for pid in PHOTOS.keys()}

# CKKS context will be set by client in HE mode
CKKS_CONTEXT = None

@app.get("/health")
def health():
    return {"status": "ok", "tenseal": bool(TENSEAL_AVAILABLE)}

@app.post("/set_context")
async def set_context(request: Request):
    global CKKS_CONTEXT
    if not TENSEAL_AVAILABLE:
        return JSONResponse({"error": "TenSEAL not installed on server. Use mode=plain."}, status_code=400)
    data = await request.json()
    try:
        CKKS_CONTEXT = ts.context_from(data["context"].encode("utf-8"))
        return {"status": "context received"}
    except Exception as e:
        return JSONResponse({"error": f"Failed to set context: {e}"}, status_code=400)

def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)

@app.post("/pnns")
async def pnns(request: Request, mode: str = Query("plain"), topk: int = Query(3)):
    """
    mode = "plain" (no HE, expects plaintext float array)
         or "he" (TenSEAL CKKS: expects hex-serialized ckks_vector; requires /set_context first)
    """
    data = await request.json()

    if mode == "plain":
        # Expect {"query": [floats...]}
        q = np.array(data.get("query", []), dtype=np.float64)
        if q.size == 0:
            return JSONResponse({"error": "Empty query"}, status_code=400)

        scores = []
        for pid, emb in EMBEDDINGS.items():
            s = cosine_similarity(q, emb)
            scores.append({"id": pid, "score": s})
        scores.sort(key=lambda x: x["score"], reverse=True)
        return {"mode": "plain", "results": scores[:topk]}

    elif mode == "he":
        if not TENSEAL_AVAILABLE:
            return JSONResponse({"error": "TenSEAL not available on server"}, status_code=400)
        if CKKS_CONTEXT is None:
            return JSONResponse({"error": "No CKKS context set. Call /set_context first."}, status_code=400)

        # Expect {"query": "<hex-serialized-ckks-vector>"}
        try:
            import tenseal as ts
            query_enc = ts.ckks_vector_from(CKKS_CONTEXT, bytes.fromhex(data["query"]))
        except Exception as e:
            return JSONResponse({"error": f"Failed to load encrypted query: {e}"}, status_code=400)

        # Compute encrypted dot products (proxy for similarity). Norms can be handled client-side if needed.
        results = []
        for pid, emb in EMBEDDINGS.items():
            emb_enc = ts.ckks_vector(CKKS_CONTEXT, emb.tolist())
            dot_enc = query_enc.dot(emb_enc).serialize()
            results.append({"id": pid, "score": dot_enc.hex()})
        return {"mode": "he", "results": results}

    else:
        return JSONResponse({"error": f"Unknown mode: {mode}"}, status_code=400)

@app.get("/get_photo/{photo_id}")
async def get_photo(photo_id: int):
    item = PHOTOS.get(photo_id)
    if not item:
        return JSONResponse({"error": "unknown photo id"}, status_code=404)
    fp = item["file"]
    if not os.path.exists(fp):
        return JSONResponse({"error": "file not found on server"}, status_code=404)
    return FileResponse(fp, media_type="image/jpeg")
