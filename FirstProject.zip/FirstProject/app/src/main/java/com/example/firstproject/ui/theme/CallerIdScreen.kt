package com.example.firstproject.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallerIdScreen(navController: NavController? = null) { // Make NavController optional for preview
    var phoneNumber by remember { mutableStateOf("") }
    var detectedName by remember { mutableStateOf<String?>(null) }
    val isPhoneNumberValid = phoneNumber.length == 10 && phoneNumber.all { it.isDigit() }

    val randomNames = listOf("Alice", "Bob", "Charlie", "Diana", "Edward", "Fiona", "George")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Caller ID Detection") },
                navigationIcon = {
                    if (navController != null) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = {
                    if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                        phoneNumber = it
                        detectedName = null // Clear previous result when number changes
                    }
                },
                label = { Text("Enter 10-digit Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (isPhoneNumberValid) {
                        detectedName = randomNames[Random.nextInt(randomNames.size)]
                    }
                },
                enabled = isPhoneNumberValid,
                modifier = Modifier.fillMaxWidth(0.6f)
            ) {
                Text("Submit")
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Filled.Send, contentDescription = "Submit Phone Number")
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (detectedName != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.AccountCircle,
                            contentDescription = "Detected User",
                            modifier = Modifier.size(40.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Detected: $detectedName",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

// Optional: Preview for CallerIdScreen
@Preview(showBackground = true)
@Composable
fun CallerIdScreenPreview() {
    MaterialTheme { // Wrap with your app's theme if you have one
        CallerIdScreen()
    }
}
