package com.example.firstproject // Replace with your package name

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.firstproject.ui.theme.CallerIdScreen
import com.example.firstproject.ui.theme.FirstProjectTheme // Replace with your theme
import com.example.firstproject.ui.theme.PetFrameworkScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FirstProjectTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "petFramework") {
        composable("petFramework") {
            PetFrameworkScreen(navController = navController)
        }
        composable("callerId") {
            CallerIdScreen()
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    FirstProjectTheme {
        AppNavigation()
    }
}
